package prove02;

public interface Growth {
    public Creature grow();
}
